<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ГрумРум</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<header>
        <div class="LG"><img src="LG.ico" width="150px"></div>
        <div class="LGT"> <p wi>ГрумРум</p></div></header>
       <?php
       include 'nav.php';
       nav(4);
       include 'db.php';
       ?>
    
</body>
</html>